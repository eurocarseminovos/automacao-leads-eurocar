# Sistema de Automação de Leads - Euro Car Seminovos

Sistema automático para processar leads de emails dos portais de veículos e enviar para o Kommo CRM.

## Configuração das Variáveis de Ambiente

Configure as seguintes variáveis no Railway:

### Email (Gmail)
- `EMAIL_SERVER`: imap.gmail.com
- `EMAIL_PORT`: 993
- `EMAIL_USERNAME`: seu-email@gmail.com
- `EMAIL_PASSWORD`: jqjv llzw wplo lipn

### Kommo CRM
- `KOMMO_SUBDOMAIN`: eurocarseminovos0
- `KOMMO_TOKEN`: eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjJhZGY3ZDllY2I4NWJlOGVjMjc1MzFlY2NlNTViYzIwNDI4NDYzNDRjZjdlODcwMmI5NjFjYTMxNTdkNjU1NDNmZmRkNTVhM2FmZmQwMTZhIn0.eyJhdWQiOiJjZDkyYjU3OS1iYjg4LTQ5NzEtYjM1Zi1jMTMzN2VkNTE4MWUiLCJqdGkiOiIyYWRmN2Q5ZWNiODViZThlYzI3NTMxZWNjZTU1YmMyMDQyODQ2MzQ0Y2Y3ZTg3MDJiOTYxY2EzMTU3ZDY1NTQzZmZkZDU1YTNhZmZkMDE2YSIsImlhdCI6MTc1NjkyMDU0OCwibmJmIjoxNzU2OTIwNTQ4LCJleHAiOjE4ODMwODgwMDAsInN1YiI6IjEzNzAwMTU2IiwiZ3JhbnRfdHlwZSI6IiIsImFjY291bnRfaWQiOjM1MDUyMjY0LCJiYXNlX2RvbWFpbiI6ImtvbW1vLmNvbSIsInZlcnNpb24iOjIsInNjb3BlcyI6WyJjcm0iLCJmaWxlcyIsImZpbGVzX2RlbGV0ZSIsIm5vdGlmaWNhdGlvbnMiLCJwdXNoX25vdGlmaWNhdGlvbnMiXSwidXNlcl9mbGFncyI6MCwiaGFzaF91dWlkIjoiMzI0MTZmNzQtNGYxMy00OWY4LWExYjctOThlOWI5ZTM4NWRkIiwiYXBpX2RvbWFpbiI6ImFwaS1jLmtvbW1vLmNvbSJ9.P6aVDcyTEOtsJXU2bP5NegRElLJmcJQsJFOn5SDad6_5miHc2D8Lv81M0C5fNa03ZNdNDsL4589xdOw81ydsQPULwpdNZjeqHcWt9FlDHPWMmvXgtdi2qxZEFYfJpJ27tSL6wHhntld02tbxJBCr0TrVTRNuR4sjANpEYRBU4mT7LqP4E-E7J2h2DdE7HBO_uRYdJXd18i-4QQJM-xl2FrNlp5h2jK5fevWcGDXaoAXtvCdaqAbZHlaZ1Bp4zTw18gMRLoB61rWUdHm_OYj0FFn9q5WlEM2H_oCJx6d0KtlIfbXpxZnB3nxVWBQ8HgcAEqFkl65iNarVCcQNGmEv2A

## Endpoints Disponíveis

- `GET /` - Página inicial
- `GET /health` - Verificar saúde do sistema
- `GET /test` - Testar processamento com dados de exemplo
- `POST /monitor/start` - Iniciar monitoramento de emails
- `POST /monitor/stop` - Parar monitoramento
- `GET /monitor/status` - Status do monitoramento

## Portais Suportados

- OLX
- Webmotors
- iCarros
- Só Carrão
- Mobi Auto
- Na Pista

## Como Usar

1. Configure as variáveis de ambiente
2. Faça o deploy no Railway
3. Acesse `/test` para testar
4. Acesse `/monitor/start` para iniciar o monitoramento automático
5. Verifique `/monitor/status` para acompanhar o status

