import os
import re
import imaplib
import email
import time
import threading
import logging
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from email.header import decode_header

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
CORS(app)

# Configurações do email e Kommo (via variáveis de ambiente)
EMAIL_CONFIG = {
    'server': os.getenv('EMAIL_SERVER', 'imap.gmail.com'),
    'port': int(os.getenv('EMAIL_PORT', 993)),
    'username': os.getenv('EMAIL_USERNAME'),
    'password': os.getenv('EMAIL_PASSWORD')
}

KOMMO_CONFIG = {
    'subdomain': os.getenv('KOMMO_SUBDOMAIN'),
    'access_token': os.getenv('KOMMO_TOKEN')
}

# Monitor de email global
email_monitor = None
monitoring_active = False

def extract_olx_data(content, sender):
    """Extrai dados de emails da OLX"""
    data = {
        'portal': 'OLX',
        'source': sender,
        'name': '',
        'phone': '',
        'email': '',
        'vehicle_interest': '',
        'whatsapp': ''
    }
    
    # Extrair nome
    name_match = re.search(r'Nome:\s*([^\n\r]+)', content)
    if name_match:
        data['name'] = name_match.group(1).strip()
    
    # Extrair email
    email_match = re.search(r'Email:\s*([^\n\r]+)', content)
    if email_match:
        data['email'] = email_match.group(1).strip()
    
    # Extrair telefone
    phone_match = re.search(r'Telefone:\s*([^\n\r]+)', content)
    if phone_match:
        phone = phone_match.group(1).strip()
        data['phone'] = phone
        data['whatsapp'] = phone  # Assumir que telefone é WhatsApp
    
    # Extrair veículo de interesse
    vehicle_match = re.search(r'([A-Z][A-Z\s]+\d+(?:\.\d+)?(?:\s+\d{4})?)', content)
    if vehicle_match:
        data['vehicle_interest'] = vehicle_match.group(1).strip()
    
    return data

def extract_socarrao_data(content, sender):
    """Extrai dados de emails do Só Carrão"""
    data = {
        'portal': 'Só Carrão',
        'source': sender,
        'name': '',
        'phone': '',
        'email': '',
        'vehicle_interest': '',
        'whatsapp': ''
    }
    
    # Extrair nome
    name_match = re.search(r'De:\s*([^\n\r]+)', content)
    if name_match:
        data['name'] = name_match.group(1).strip()
    
    # Extrair email
    email_match = re.search(r'Email:\s*([^\n\r]+)', content)
    if email_match:
        data['email'] = email_match.group(1).strip()
    
    # Extrair telefone
    phone_match = re.search(r'Telefone:\s*([^\n\r]+)', content)
    if phone_match:
        phone = phone_match.group(1).strip()
        data['phone'] = phone
        data['whatsapp'] = phone
    
    # Extrair informações do veículo
    vehicle_info = []
    
    # Modelo
    model_match = re.search(r'Modelo:\s*([^\n\r]+)', content)
    if model_match:
        vehicle_info.append(model_match.group(1).strip())
    
    # Ano
    year_match = re.search(r'Ano:\s*([^\n\r]+)', content)
    if year_match:
        vehicle_info.append(year_match.group(1).strip())
    
    # Valor
    value_match = re.search(r'Valor:\s*([^\n\r]+)', content)
    if value_match:
        vehicle_info.append(f"R$ {value_match.group(1).strip()}")
    
    if vehicle_info:
        data['vehicle_interest'] = ' - '.join(vehicle_info)
    
    return data

def extract_icarros_data(content, sender):
    """Extrai dados de emails do iCarros"""
    data = {
        'portal': 'iCarros',
        'source': sender,
        'name': '',
        'phone': '',
        'email': '',
        'vehicle_interest': '',
        'whatsapp': ''
    }
    
    # Extrair nome
    name_match = re.search(r'Nome\s+([^\n\r]+)', content)
    if name_match:
        data['name'] = name_match.group(1).strip()
    
    # Extrair email
    email_match = re.search(r'E-mail\s+([^\n\r]+)', content)
    if email_match:
        data['email'] = email_match.group(1).strip()
    
    # Extrair telefone
    phone_match = re.search(r'Telefone\s+([^\n\r]+)', content)
    if phone_match:
        phone = phone_match.group(1).strip()
        data['phone'] = phone
        data['whatsapp'] = phone
    
    # Extrair anúncio (veículo)
    vehicle_match = re.search(r'Anúncio:\s*([^\n\r]+)', content)
    if vehicle_match:
        data['vehicle_interest'] = vehicle_match.group(1).strip()
    
    return data

def send_to_kommo(lead_data):
    """Envia lead para o Kommo CRM"""
    try:
        if not KOMMO_CONFIG['subdomain'] or not KOMMO_CONFIG['access_token']:
            return {'success': False, 'error': 'Configurações do Kommo não encontradas'}
        
        # URL da API do Kommo
        url = f"https://{KOMMO_CONFIG['subdomain']}.kommo.com/api/v4/leads"
        
        headers = {
            'Authorization': f"Bearer {KOMMO_CONFIG['access_token']}",
            'Content-Type': 'application/json'
        }
        
        # Preparar dados do lead
        lead_payload = {
            'name': f"Lead {lead_data['portal']} - {lead_data['name']}",
            'price': 0,
            'custom_fields_values': [],
            '_embedded': {
                'contacts': [{
                    'name': lead_data['name'],
                    'custom_fields_values': []
                }]
            }
        }
        
        # Adicionar telefone ao contato se disponível
        if lead_data['phone']:
            lead_payload['_embedded']['contacts'][0]['custom_fields_values'].append({
                'field_code': 'PHONE',
                'values': [{'value': lead_data['phone'], 'enum_code': 'WORK'}]
            })
        
        # Adicionar email ao contato se disponível
        if lead_data['email']:
            lead_payload['_embedded']['contacts'][0]['custom_fields_values'].append({
                'field_code': 'EMAIL',
                'values': [{'value': lead_data['email'], 'enum_code': 'WORK'}]
            })
        
        # Criar observações com todas as informações
        notes = []
        notes.append(f"🚗 Portal: {lead_data['portal']}")
        if lead_data['vehicle_interest']:
            notes.append(f"🚙 Veículo: {lead_data['vehicle_interest']}")
        if lead_data['whatsapp']:
            notes.append(f"📱 WhatsApp: {lead_data['whatsapp']}")
        notes.append(f"📧 Origem: {lead_data['source']}")
        notes.append(f"⏰ Processado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}")
        
        # Fazer requisição para criar lead
        response = requests.post(url, json=[lead_payload], headers=headers, timeout=30)
        
        if response.status_code == 200:
            lead_response = response.json()
            lead_id = lead_response['_embedded']['leads'][0]['id']
            
            # Adicionar nota ao lead
            notes_url = f"https://{KOMMO_CONFIG['subdomain']}.kommo.com/api/v4/leads/{lead_id}/notes"
            note_payload = [{
                'note_type': 'common',
                'params': {
                    'text': '\n'.join(notes)
                }
            }]
            
            requests.post(notes_url, json=note_payload, headers=headers, timeout=30)
            
            return {
                'success': True,
                'lead_id': lead_id,
                'message': 'Lead criado com sucesso no Kommo'
            }
        else:
            return {
                'success': False,
                'error': f'Erro na API do Kommo: {response.status_code} - {response.text}'
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': f'Erro ao enviar para Kommo: {str(e)}'
        }

def process_email_content(sender, subject, content):
    """Processa conteúdo do email e extrai dados do lead"""
    try:
        # Identificar portal baseado no remetente
        sender_lower = sender.lower()
        
        if 'olx.com.br' in sender_lower:
            return extract_olx_data(content, sender)
        elif 'socarrao.com.br' in sender_lower:
            return extract_socarrao_data(content, sender)
        elif 'icarros.com.br' in sender_lower:
            return extract_icarros_data(content, sender)
        elif 'webmotors.com.br' in sender_lower:
            # Usar extração similar ao iCarros para webmotors
            data = extract_icarros_data(content, sender)
            data['portal'] = 'Webmotors'
            return data
        elif 'mobiauto.com.br' in sender_lower:
            data = extract_icarros_data(content, sender)
            data['portal'] = 'Mobi Auto'
            return data
        elif 'napista.com.br' in sender_lower:
            data = extract_icarros_data(content, sender)
            data['portal'] = 'Na Pista'
            return data
        else:
            # Portal desconhecido, tentar extração genérica
            return {
                'portal': 'Desconhecido',
                'source': sender,
                'name': '',
                'phone': '',
                'email': '',
                'vehicle_interest': subject,
                'whatsapp': ''
            }
            
    except Exception as e:
        logger.error(f"Erro ao processar email: {str(e)}")
        return None

class EmailMonitor:
    def __init__(self):
        self.running = False
        self.thread = None
        self.processed_emails = set()
    
    def connect_to_email(self):
        try:
            mail = imaplib.IMAP4_SSL(EMAIL_CONFIG['server'], EMAIL_CONFIG['port'])
            mail.login(EMAIL_CONFIG['username'], EMAIL_CONFIG['password'])
            return mail
        except Exception as e:
            logger.error(f"Erro ao conectar ao email: {str(e)}")
            return None
    
    def decode_header(self, header):
        if header is None:
            return ""
        decoded_parts = decode_header(header)
        decoded_header = ""
        for part, encoding in decoded_parts:
            if isinstance(part, bytes):
                if encoding:
                    decoded_header += part.decode(encoding)
                else:
                    decoded_header += part.decode('utf-8', errors='ignore')
            else:
                decoded_header += part
        return decoded_header
    
    def extract_content(self, msg):
        content = ""
        if msg.is_multipart():
            for part in msg.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get("Content-Disposition"))
                if content_type == "text/plain" and "attachment" not in content_disposition:
                    body = part.get_payload(decode=True)
                    if body:
                        content += body.decode('utf-8', errors='ignore')
        else:
            body = msg.get_payload(decode=True)
            if body:
                content = body.decode('utf-8', errors='ignore')
        return content
    
    def is_vehicle_email(self, sender, subject):
        portals = ['olx.com.br', 'webmotors.com.br', 'icarros.com.br', 
                  'socarrao.com.br', 'mobiauto.com.br', 'napista.com.br']
        
        for portal in portals:
            if portal in sender.lower():
                return True
        
        keywords = ['interessado', 'lead', 'cliente', 'veículo', 'carro', 'proposta']
        for keyword in keywords:
            if keyword in subject.lower():
                return True
        
        return False
    
    def monitor_loop(self):
        logger.info("Iniciando monitoramento de emails...")
        
        while self.running:
            try:
                mail = self.connect_to_email()
                if not mail:
                    time.sleep(30)
                    continue
                
                mail.select('INBOX')
                status, messages = mail.search(None, 'UNSEEN')
                
                if status == 'OK':
                    email_ids = messages[0].split()
                    
                    for email_id in email_ids:
                        if not self.running:
                            break
                        
                        if email_id in self.processed_emails:
                            continue
                        
                        try:
                            status, msg_data = mail.fetch(email_id, '(RFC822)')
                            if status == 'OK':
                                msg = email.message_from_bytes(msg_data[0][1])
                                
                                sender = self.decode_header(msg.get('From', ''))
                                subject = self.decode_header(msg.get('Subject', ''))
                                content = self.extract_content(msg)
                                
                                logger.info(f"Email de: {sender}")
                                
                                if self.is_vehicle_email(sender, subject):
                                    logger.info("Email de portal de veículos detectado")
                                    
                                    lead_data = process_email_content(sender, subject, content)
                                    if lead_data:
                                        kommo_result = send_to_kommo(lead_data)
                                        if kommo_result['success']:
                                            logger.info(f"Lead enviado para Kommo: {kommo_result['lead_id']}")
                                        else:
                                            logger.error(f"Erro ao enviar para Kommo: {kommo_result['error']}")
                                
                                self.processed_emails.add(email_id)
                        
                        except Exception as e:
                            logger.error(f"Erro ao processar email: {str(e)}")
                
                mail.close()
                mail.logout()
                
                # Aguardar 60 segundos antes da próxima verificação
                for _ in range(60):
                    if not self.running:
                        break
                    time.sleep(1)
                    
            except Exception as e:
                logger.error(f"Erro no monitoramento: {str(e)}")
                time.sleep(30)
    
    def start(self):
        if self.running:
            return False
        
        self.running = True
        self.thread = threading.Thread(target=self.monitor_loop)
        self.thread.daemon = True
        self.thread.start()
        return True
    
    def stop(self):
        if not self.running:
            return False
        
        self.running = False
        if self.thread:
            self.thread.join(timeout=10)
        return True
    
    def get_status(self):
        return {
            'running': self.running,
            'processed_count': len(self.processed_emails),
            'email_account': EMAIL_CONFIG.get('username', 'N/A')
        }

# Rotas da API
@app.route('/')
def home():
    return jsonify({
        'message': 'Sistema de Automação de Leads - Euro Car Seminovos',
        'status': 'online',
        'endpoints': {
            'health': '/health',
            'test': '/test',
            'start_monitoring': '/monitor/start',
            'stop_monitoring': '/monitor/stop',
            'monitor_status': '/monitor/status'
        }
    })

@app.route('/health')
def health():
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

@app.route('/test')
def test():
    # Testar com dados de exemplo da OLX
    sample_content = """
    Oi, Eurocar!

    Você recebeu um novo interessado em comprar o seu veículo e o cliente aceitou compartilhar as informações de contato com você:

    FIAT FIAT UNO ATTRACTIVE 1.0 2020
    R$ 42900,00

    Nome: Wesley Pablo
    Email: wesleypabloecia@gmail.com
    Telefone: 43999155017

    Identificador do lead: 4d39ccc6-5846-4d18-8fa8-754d12a773fc
    """
    
    lead_data = extract_olx_data(sample_content, "noreply@olx.com.br")
    kommo_result = send_to_kommo(lead_data)
    
    return jsonify({
        'test_data': lead_data,
        'kommo_result': kommo_result,
        'status': 'test_completed'
    })

@app.route('/monitor/start', methods=['POST'])
def start_monitoring():
    global email_monitor, monitoring_active
    
    if not EMAIL_CONFIG['username'] or not EMAIL_CONFIG['password']:
        return jsonify({
            'success': False,
            'error': 'Configurações de email não encontradas'
        }), 400
    
    if not email_monitor:
        email_monitor = EmailMonitor()
    
    if email_monitor.start():
        monitoring_active = True
        return jsonify({
            'success': True,
            'message': 'Monitoramento iniciado',
            'status': email_monitor.get_status()
        })
    else:
        return jsonify({
            'success': False,
            'error': 'Monitoramento já está ativo'
        }), 400

@app.route('/monitor/stop', methods=['POST'])
def stop_monitoring():
    global email_monitor, monitoring_active
    
    if email_monitor and email_monitor.stop():
        monitoring_active = False
        return jsonify({
            'success': True,
            'message': 'Monitoramento parado'
        })
    else:
        return jsonify({
            'success': False,
            'error': 'Nenhum monitoramento ativo'
        }), 400

@app.route('/monitor/status')
def monitor_status():
    global email_monitor, monitoring_active
    
    if email_monitor:
        return jsonify({
            'success': True,
            'status': email_monitor.get_status()
        })
    else:
        return jsonify({
            'success': True,
            'status': {
                'running': False,
                'processed_count': 0,
                'email_account': 'N/A'
            }
        })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

